from django.contrib import admin

from .models import User_socialaccount_and_about


admin.site.register(User_socialaccount_and_about)

