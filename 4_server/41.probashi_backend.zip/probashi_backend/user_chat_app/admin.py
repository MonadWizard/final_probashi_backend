from django.contrib import admin
from .models import RoomGroupNameTable


admin.site.register(RoomGroupNameTable)
