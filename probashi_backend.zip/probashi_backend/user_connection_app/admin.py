from django.contrib import admin
from .models import User_consultant, user_consult_appointment

# Register your models here.
admin.site.register(User_consultant)
admin.site.register(user_consult_appointment)

